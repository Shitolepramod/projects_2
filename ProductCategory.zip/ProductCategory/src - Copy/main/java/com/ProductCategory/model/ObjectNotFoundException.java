package com.ProductCategory.model;

public class ObjectNotFoundException extends RuntimeException
{
	
	public ObjectNotFoundException(String message)
	{
		super(message);
	}

}
