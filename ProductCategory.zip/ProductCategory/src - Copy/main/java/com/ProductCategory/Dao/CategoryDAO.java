package com.ProductCategory.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ProductCategory.model.Category;




@Repository
public class CategoryDAO {

	@Autowired
	SessionFactory factory;

	
	@SuppressWarnings("deprecation")
	public List<Category> getAllCategory() 
	{
		Session s=factory.openSession();
		Criteria c=s.createCriteria(Category.class);
		List<Category>lc=c.list();
		return lc;
	}

	public Category saveCategory(Category c)
	{
		Session s=factory.openSession();
		Transaction tr=s.beginTransaction();
		s.save(c);
		tr.commit();
		return c;
		
	}
	
	
	public Category getCategory(int cid)
	{
		Session s=factory.openSession();
		Category c=s.get(Category.class,cid);
		return c;
	}
	

	
	public Category updateCategory(Category c)
	{
		Session s=factory.openSession();
		Transaction tr=s.beginTransaction();
		s.update(c);
		tr.commit();
		return c;
	}
	
	

	public Category deleteCategory(int cid)
	{
		Session s=factory.openSession();
		Transaction tr=s.beginTransaction();
		Category c=s.get(Category.class,cid);
		s.delete(c);
		tr.commit();
		return c;
	}

}
