package com.ProductCategory.servise;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ProductCategory.Dao.CategoryDAO;
import com.ProductCategory.model.Category;



@Service
public class CategoryService {

	@Autowired
	CategoryDAO dao;

	public List<Category> getAllCategory() 
	{
		return dao.getAllCategory();
	}
	
	
	public Category saveCategory(Category c)
	{
		return dao.saveCategory(c);
	}
	
	
	public Category getCategory(int cid)
	{
		Category c=dao.getCategory(cid);
		return c;
	}
	
	
	public Category updateCategory(Category c)
	{
		return dao.updateCategory(c);
	}
	
	
	public Category deleteCategory(int cid)
	{
		return dao.deleteCategory(cid);
	}
	
	
}
