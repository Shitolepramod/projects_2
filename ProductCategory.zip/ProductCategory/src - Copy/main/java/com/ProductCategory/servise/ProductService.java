package com.ProductCategory.servise;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ProductCategory.Dao.ProductDAO;
import com.ProductCategory.model.Product;


@Service
public class ProductService {

       @Autowired
       ProductDAO dao;
       
    	

	public List<Product> getAllProduct() {
		return dao.getAllProduct();
	}
	
	
	public Product saveProduct(Product p) {
		
		return dao.saveProduct(p);
	}

	public Product getProduct(int pid) {
		return dao.getProduct(pid);
		
	}
	
	
	public Product updateProduct(Product p)
	{
		return  dao.updateProduct(p);
	}
		
	
	public Product deleteProduct(int pid)
	{
		return dao.deleteProduct(pid);
	}
}
